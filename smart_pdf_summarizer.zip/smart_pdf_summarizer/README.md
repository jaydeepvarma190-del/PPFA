# 📚 Smart PDF Summarizer for Students

An AI-powered, production-ready PDF summarizer built with **Streamlit**, **Python**, and either **Google Gemini** or **OpenAI**.

---

## ✨ Features

| Feature | Description |
|---|---|
| **7 Summary Types** | Short, Detailed, Bullet, Chapter-wise, Exam Notes, Key Concepts, Definitions |
| **200+ Prompts** | Curated library across 7 categories |
| **5 Export Formats** | PDF, DOCX, PPTX, TXT, Markdown |
| **Video Generator** | Slide-style educational video from summary |
| **Search & Highlight** | Find keywords in the generated summary |
| **Multi-language** | Output in 11 languages |
| **OCR Support** | Extracts text from scanned PDFs (with Tesseract) |
| **Dashboard** | Session statistics and history |
| **Dark / Light Mode** | Full theme toggle |

---

## 🗂️ Project Structure

```
smart_pdf_summarizer/
│
├── app.py                    # Main Streamlit application
├── requirements.txt          # All dependencies
├── .env.example              # Environment variable template
├── .streamlit/
│   └── config.toml           # Streamlit theme & server config
│
├── utils/
│   ├── __init__.py
│   ├── pdf_reader.py         # PDF extraction (PyMuPDF, pdfplumber, PyPDF2, OCR)
│   ├── summarizer.py         # AI summarization (Gemini & OpenAI)
│   ├── exporter.py           # Export to PDF, DOCX, PPTX, TXT, Markdown
│   └── video_generator.py    # Slide-style video generation
│
├── prompts/
│   └── prompts.json          # 200+ categorized prompts
│
├── outputs/                  # Generated files (auto-created)
└── README.md
```

---

## 🚀 Local Setup

### Prerequisites

- Python 3.10+
- pip

### Step 1 — Clone and install

```bash
git clone https://github.com/your-username/smart-pdf-summarizer.git
cd smart-pdf-summarizer
pip install -r requirements.txt
```

### Step 2 — Configure API keys

```bash
cp .env.example .env
# Edit .env and add your Gemini or OpenAI API key
```

Or export environment variables directly:
```bash
export GEMINI_API_KEY="your_key_here"
# or
export OPENAI_API_KEY="your_key_here"
```

### Step 3 — Run

```bash
streamlit run app.py
```

Open [http://localhost:8501](http://localhost:8501) in your browser.

---

## ☁️ Deploy to Streamlit Cloud

### Step 1 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/smart-pdf-summarizer.git
git push -u origin main
```

### Step 2 — Create Streamlit Cloud App

1. Go to [https://share.streamlit.io](https://share.streamlit.io)
2. Click **"New app"**
3. Select your repository and branch
4. Set **Main file path** to `app.py`
5. Click **"Advanced settings"** → add Secrets:

```toml
GEMINI_API_KEY = "your_gemini_api_key_here"
OPENAI_API_KEY = "your_openai_api_key_here"
```

6. Click **"Deploy!"**

Your app will be live at `https://your-app-name.streamlit.app`

---

## 🔑 Getting API Keys

### Google Gemini (Free tier available)
1. Visit [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
2. Sign in with Google
3. Click **"Create API key"**
4. Copy the key

### OpenAI
1. Visit [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Sign in / create account
3. Click **"Create new secret key"**
4. Copy the key (it's shown only once)

---

## 📦 Optional Features

### OCR for Scanned PDFs

Install system dependencies:

```bash
# Ubuntu/Debian
sudo apt-get install tesseract-ocr poppler-utils

# macOS
brew install tesseract poppler
```

Then uncomment in `requirements.txt`:
```
pytesseract>=0.3.10
pdf2image>=1.17.0
```

### Voice Narration in Videos

gTTS is already included in requirements. Requires internet access for TTS generation.

---

## 💡 Usage Tips

- **Large PDFs**: The app automatically chunks documents over ~12,000 characters.
- **Scanned PDFs**: Install Tesseract for OCR support.
- **Custom Prompts**: Use the Prompt Library or write your own custom prompt.
- **Video Export**: Requires imageio[ffmpeg] with FFmpeg available.

---

## 🛠️ Tech Stack

- **Frontend**: Streamlit
- **AI**: Google Gemini 1.5 Flash / OpenAI GPT-4o Mini
- **PDF Extraction**: PyMuPDF, pdfplumber, PyPDF2
- **Export**: reportlab (PDF), python-docx (Word), python-pptx (PowerPoint)
- **Video**: imageio + Pillow
- **TTS**: gTTS

---

## 📄 License

MIT License — free to use and modify.
