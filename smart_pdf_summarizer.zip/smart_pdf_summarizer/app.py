"""
Smart PDF Summarizer for Students
===================================
A production-ready AI-powered PDF summarizer built with Streamlit.
Supports Google Gemini and OpenAI APIs.
"""

import os
import re
import json
import time
import logging
import hashlib
from datetime import datetime
from pathlib import Path

import streamlit as st

# ─── Page config (must be first Streamlit call) ────────────────────────────────
st.set_page_config(
    page_title="Smart PDF Summarizer",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
PROMPTS_FILE = BASE_DIR / "prompts" / "prompts.json"
OUTPUTS_DIR = BASE_DIR / "outputs"
OUTPUTS_DIR.mkdir(exist_ok=True)

# ─── Import utilities ─────────────────────────────────────────────────────────
from utils.pdf_reader import read_pdf
from utils.summarizer import generate_summary, SUMMARY_PROMPTS
from utils.exporter import export_summary
from utils.video_generator import generate_video

# ─── Load prompt library ──────────────────────────────────────────────────────
@st.cache_data
def load_prompts() -> dict:
    try:
        with open(PROMPTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

PROMPT_LIBRARY = load_prompts()

# ─── Session state defaults ───────────────────────────────────────────────────
def init_session():
    defaults = {
        "pdf_data": None,           # dict from read_pdf
        "summary": None,            # generated summary string
        "summary_type": None,
        "history": [],              # list of {filename, summary_type, summary, ts}
        "dark_mode": True,
        "total_pages": 0,
        "total_words": 0,
        "total_pdfs": 0,
        "processing_time": 0.0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_session()

# ─── Custom CSS ───────────────────────────────────────────────────────────────
DARK_THEME = """
<style>
/* ── Base ───────────────────────────────────────────── */
[data-testid="stAppViewContainer"] {
    background: #0f172a;
    color: #e2e8f0;
}
[data-testid="stSidebar"] {
    background: #1e293b !important;
    border-right: 1px solid #334155;
}
[data-testid="stSidebar"] * { color: #e2e8f0 !important; }
[data-testid="stHeader"] { background: transparent; }

/* ── Cards ──────────────────────────────────────────── */
.stat-card {
    background: #1e293b;
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 20px 24px;
    text-align: center;
    transition: transform 0.2s, box-shadow 0.2s;
}
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(26,86,219,0.2);
}
.stat-number { font-size: 2.4rem; font-weight: 700; color: #60a5fa; line-height: 1; }
.stat-label { font-size: 0.85rem; color: #94a3b8; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.05em; }

/* ── Summary output ─────────────────────────────────── */
.summary-box {
    background: #1e293b;
    border: 1px solid #334155;
    border-left: 4px solid #1a56db;
    border-radius: 0 12px 12px 0;
    padding: 24px;
    white-space: pre-wrap;
    font-size: 0.95rem;
    line-height: 1.7;
    color: #e2e8f0;
    max-height: 550px;
    overflow-y: auto;
}
.summary-box::-webkit-scrollbar { width: 6px; }
.summary-box::-webkit-scrollbar-track { background: #0f172a; }
.summary-box::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }

/* ── Highlight ──────────────────────────────────────── */
.highlight { background-color: #fbbf24; color: #0f172a; border-radius: 3px; padding: 0 2px; }

/* ── Badges ─────────────────────────────────────────── */
.badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    margin: 2px;
}
.badge-blue { background: #1e3a8a; color: #93c5fd; }
.badge-green { background: #14532d; color: #86efac; }
.badge-orange { background: #7c2d12; color: #fdba74; }

/* ── Upload zone ─────────────────────────────────────── */
[data-testid="stFileUploader"] {
    background: #1e293b;
    border: 2px dashed #334155;
    border-radius: 12px;
    padding: 10px;
    transition: border-color 0.2s;
}
[data-testid="stFileUploader"]:hover { border-color: #1a56db; }

/* ── Buttons ─────────────────────────────────────────── */
.stButton > button {
    background: linear-gradient(135deg, #1a56db, #1d4ed8) !important;
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 10px 24px !important;
    font-weight: 600 !important;
    transition: all 0.2s !important;
}
.stButton > button:hover {
    background: linear-gradient(135deg, #1d4ed8, #2563eb) !important;
    transform: translateY(-1px);
    box-shadow: 0 4px 14px rgba(26,86,219,0.4) !important;
}

/* ── Selectbox / inputs ──────────────────────────────── */
[data-testid="stSelectbox"] > div > div,
[data-testid="stTextInput"] > div > div > input,
[data-testid="stTextArea"] > div > div > textarea {
    background: #1e293b !important;
    border: 1px solid #334155 !important;
    color: #e2e8f0 !important;
    border-radius: 8px !important;
}
[data-testid="stTextArea"] > div > div > textarea { font-family: inherit; }

/* ── Section headers ─────────────────────────────────── */
.section-header {
    font-size: 1.1rem;
    font-weight: 700;
    color: #93c5fd;
    margin: 16px 0 8px;
    padding-bottom: 6px;
    border-bottom: 1px solid #334155;
}

/* ── Toast / info boxes ──────────────────────────────── */
[data-testid="stInfo"] { background: #1e3a8a22; border-color: #1a56db; }
[data-testid="stSuccess"] { background: #14532d22; border-color: #16a34a; }
[data-testid="stWarning"] { background: #78350f22; border-color: #d97706; }
[data-testid="stError"] { background: #7f1d1d22; border-color: #dc2626; }

/* ── History items ───────────────────────────────────── */
.history-item {
    background: #1e293b;
    border: 1px solid #334155;
    border-radius: 8px;
    padding: 12px 16px;
    margin-bottom: 8px;
    font-size: 0.88rem;
}
.history-item .ts { color: #64748b; font-size: 0.75rem; }

/* ── Progress bar ────────────────────────────────────── */
[data-testid="stProgressBar"] > div { background: #1a56db !important; }

/* ── Tabs ────────────────────────────────────────────── */
[data-testid="stTabs"] [data-baseweb="tab"] {
    color: #94a3b8 !important;
    border-bottom: 2px solid transparent !important;
}
[data-testid="stTabs"] [data-baseweb="tab"][aria-selected="true"] {
    color: #60a5fa !important;
    border-bottom: 2px solid #1a56db !important;
}
</style>
"""

LIGHT_THEME = """
<style>
[data-testid="stAppViewContainer"] { background: #f8fafc; color: #1e293b; }
[data-testid="stSidebar"] { background: #f1f5f9 !important; border-right: 1px solid #e2e8f0; }
.stat-card { background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px 24px; text-align: center; }
.stat-number { font-size: 2.4rem; font-weight: 700; color: #1d4ed8; line-height: 1; }
.stat-label { font-size: 0.85rem; color: #64748b; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.05em; }
.summary-box { background: white; border: 1px solid #e2e8f0; border-left: 4px solid #1a56db; border-radius: 0 12px 12px 0; padding: 24px; white-space: pre-wrap; font-size: 0.95rem; line-height: 1.7; max-height: 550px; overflow-y: auto; }
.section-header { font-size: 1.1rem; font-weight: 700; color: #1d4ed8; margin: 16px 0 8px; padding-bottom: 6px; border-bottom: 1px solid #e2e8f0; }
.stButton > button { background: linear-gradient(135deg, #1a56db, #1d4ed8) !important; color: white !important; border: none !important; border-radius: 8px !important; }
.highlight { background-color: #fbbf24; color: #0f172a; border-radius: 3px; padding: 0 2px; }
</style>
"""

st.markdown(DARK_THEME if st.session_state.dark_mode else LIGHT_THEME, unsafe_allow_html=True)


# ─── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 📚 Smart PDF Summarizer")
    st.markdown('<div style="color:#64748b;font-size:0.8rem;margin-bottom:16px">AI-powered study companion for students</div>', unsafe_allow_html=True)
    st.divider()

    # Navigation
    page = st.radio(
        "Navigate",
        ["🏠 Home", "📄 Summarize", "📚 Prompt Library", "📊 Dashboard", "📜 History"],
        label_visibility="collapsed",
    )

    st.divider()
    st.markdown('<div class="section-header">⚙️ Settings</div>', unsafe_allow_html=True)

    # API Provider
    api_provider = st.selectbox("AI Provider", ["Google Gemini", "OpenAI"])

    # API Key
    api_key_env = os.environ.get("GEMINI_API_KEY" if api_provider == "Google Gemini" else "OPENAI_API_KEY", "")
    api_key = st.text_input(
        f"{'Gemini' if api_provider == 'Google Gemini' else 'OpenAI'} API Key",
        value=api_key_env,
        type="password",
        help="Your API key is never stored or logged.",
    )

    # Language
    language = st.selectbox(
        "Output Language",
        ["English", "Hindi", "Spanish", "French", "German", "Arabic",
         "Chinese", "Japanese", "Portuguese", "Telugu", "Tamil"],
    )

    # Dark mode
    st.session_state.dark_mode = st.toggle("🌙 Dark Mode", value=st.session_state.dark_mode)

    st.divider()
    st.markdown(
        '<div style="color:#475569;font-size:0.75rem;text-align:center">'
        'Smart PDF Summarizer v1.0<br>Built with Streamlit + AI</div>',
        unsafe_allow_html=True,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE: Home
# ═══════════════════════════════════════════════════════════════════════════════
if page == "🏠 Home":
    st.markdown("""
    <div style="text-align:center;padding:40px 0 20px">
        <div style="font-size:4rem">📚</div>
        <h1 style="font-size:2.4rem;font-weight:800;margin:0;
                   background:linear-gradient(135deg,#60a5fa,#a78bfa);
                   -webkit-background-clip:text;-webkit-text-fill-color:transparent">
            Smart PDF Summarizer
        </h1>
        <p style="color:#94a3b8;font-size:1.1rem;margin-top:8px">
            AI-powered study companion for students
        </p>
    </div>
    """, unsafe_allow_html=True)

    # Feature cards
    col1, col2, col3, col4 = st.columns(4)
    features = [
        ("🤖", "AI Summaries", "7 summary types powered by Gemini & OpenAI"),
        ("📦", "Export Anywhere", "PDF, DOCX, PPTX, TXT, Markdown"),
        ("🎬", "Video Generator", "Auto slide-style educational videos"),
        ("📚", "200+ Prompts", "Categorized prompt library for every need"),
    ]
    for col, (icon, title, desc) in zip([col1, col2, col3, col4], features):
        with col:
            st.markdown(f"""
            <div class="stat-card">
                <div style="font-size:2rem">{icon}</div>
                <div style="font-weight:700;color:#e2e8f0;margin:8px 0 4px">{title}</div>
                <div style="color:#94a3b8;font-size:0.82rem">{desc}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Quick start
    st.markdown("### 🚀 Quick Start")
    q1, q2, q3, q4 = st.columns(4)
    steps = [
        ("1", "Upload PDF", "Drag & drop your study material"),
        ("2", "Choose Type", "Pick a summary style"),
        ("3", "Generate", "AI creates your summary"),
        ("4", "Export", "Download in your preferred format"),
    ]
    for col, (num, t, d) in zip([q1, q2, q3, q4], steps):
        with col:
            st.markdown(f"""
            <div style="background:#1e293b;border:1px solid #334155;border-radius:10px;
                        padding:16px;text-align:center">
                <div style="background:#1a56db;color:white;width:32px;height:32px;
                            border-radius:50%;display:flex;align-items:center;
                            justify-content:center;margin:0 auto 8px;font-weight:700">{num}</div>
                <div style="font-weight:600;color:#e2e8f0">{t}</div>
                <div style="color:#64748b;font-size:0.8rem;margin-top:4px">{d}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.info("👈 Get started by selecting **📄 Summarize** from the sidebar, then upload your PDF and enter your API key.")


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE: Summarize
# ═══════════════════════════════════════════════════════════════════════════════
elif page == "📄 Summarize":
    st.markdown("## 📄 Summarize PDF")

    # ── Upload ────────────────────────────────────────────────────────────────
    st.markdown('<div class="section-header">1. Upload PDF(s)</div>', unsafe_allow_html=True)
    uploaded_files = st.file_uploader(
        "Drag & drop or click to upload",
        type=["pdf"],
        accept_multiple_files=True,
        help="Supports single or multiple PDFs. Max 50 MB each.",
    )

    if uploaded_files:
        # Select which PDF to work with
        file_names = [f.name for f in uploaded_files]
        selected_name = st.selectbox("Select PDF to summarize:", file_names) if len(uploaded_files) > 1 else file_names[0]
        selected_file = next(f for f in uploaded_files if f.name == selected_name)

        # Read PDF
        with st.spinner("📖 Extracting text from PDF…"):
            try:
                file_bytes = selected_file.read()
                pdf_data = read_pdf(file_bytes)
                st.session_state.pdf_data = pdf_data

                # Update dashboard stats
                st.session_state.total_pages += pdf_data["num_pages"]
                st.session_state.total_words += pdf_data["word_count"]
                st.session_state.total_pdfs += 1
                st.session_state.processing_time += pdf_data["processing_time"]

            except ValueError as e:
                st.error(f"❌ {e}")
                st.stop()
            except Exception as e:
                st.error(f"❌ Unexpected error reading PDF: {e}")
                st.stop()

        # PDF Info
        pdf_data = st.session_state.pdf_data
        ic1, ic2, ic3, ic4 = st.columns(4)
        with ic1:
            st.markdown(f'<div class="stat-card"><div class="stat-number">{pdf_data["num_pages"]}</div><div class="stat-label">Pages</div></div>', unsafe_allow_html=True)
        with ic2:
            st.markdown(f'<div class="stat-card"><div class="stat-number">{pdf_data["word_count"]:,}</div><div class="stat-label">Words</div></div>', unsafe_allow_html=True)
        with ic3:
            st.markdown(f'<div class="stat-card"><div class="stat-number">{pdf_data["processing_time"]}s</div><div class="stat-label">Read Time</div></div>', unsafe_allow_html=True)
        with ic4:
            status = "🔍 Scanned" if pdf_data["is_scanned"] else "✅ Text-based"
            st.markdown(f'<div class="stat-card"><div class="stat-number" style="font-size:1.4rem">{status}</div><div class="stat-label">PDF Type</div></div>', unsafe_allow_html=True)

        if pdf_data["is_scanned"]:
            st.warning("⚠️ Scanned PDF detected. OCR was applied — results may vary.")

        # Preview extracted text
        with st.expander("👁️ Preview Extracted Text", expanded=False):
            st.text_area("Extracted content (first 3000 chars):",
                         pdf_data["text"][:3000] + ("…" if len(pdf_data["text"]) > 3000 else ""),
                         height=200, disabled=True)

        st.divider()

        # ── Summary Options ───────────────────────────────────────────────────
        st.markdown('<div class="section-header">2. Choose Summary Type</div>', unsafe_allow_html=True)

        col_left, col_right = st.columns([1, 1])
        with col_left:
            summary_type = st.selectbox(
                "Summary Type",
                list(SUMMARY_PROMPTS.keys()),
                help="Choose the kind of output you need.",
            )
        with col_right:
            custom_prompt_input = ""
            if summary_type == "Custom Prompt":
                custom_prompt_input = st.text_area(
                    "Your Custom Prompt",
                    placeholder="e.g. Explain this document as if I'm 10 years old…",
                    height=80,
                )

        # Prompt Library quick-pick
        with st.expander("📚 Pick from Prompt Library (optional)", expanded=False):
            category = st.selectbox("Category", list(PROMPT_LIBRARY.keys()))
            prompts_in_cat = PROMPT_LIBRARY.get(category, [])
            selected_prompt = st.selectbox("Select Prompt", prompts_in_cat)
            if st.button("Use this prompt"):
                st.session_state["override_prompt"] = selected_prompt
                st.success(f"✅ Prompt set: {selected_prompt[:80]}…")

        override = st.session_state.get("override_prompt", "")
        effective_prompt = override if override else custom_prompt_input

        st.divider()

        # ── Generate ──────────────────────────────────────────────────────────
        st.markdown('<div class="section-header">3. Generate Summary</div>', unsafe_allow_html=True)

        if st.button("✨ Generate Summary", use_container_width=True):
            if not api_key:
                st.error("❌ Please enter your API key in the sidebar.")
            else:
                progress_bar = st.progress(0, "Starting…")
                status_text = st.empty()

                def update_progress(fraction: float, message: str):
                    progress_bar.progress(fraction, message)
                    status_text.info(f"⏳ {message}")

                try:
                    update_progress(0.1, "Sending to AI…")
                    summary = generate_summary(
                        text=pdf_data["text"],
                        summary_type=summary_type if not override else "Custom Prompt",
                        api_provider=api_provider,
                        api_key=api_key,
                        custom_prompt=effective_prompt or None,
                        language=language,
                        progress_callback=update_progress,
                    )
                    progress_bar.progress(1.0, "Done!")
                    status_text.empty()
                    st.session_state.summary = summary
                    st.session_state.summary_type = summary_type
                    st.session_state["override_prompt"] = ""  # reset

                    # Save to history
                    st.session_state.history.insert(0, {
                        "filename": selected_name,
                        "summary_type": summary_type,
                        "summary": summary,
                        "language": language,
                        "ts": datetime.now().strftime("%d %b %Y, %H:%M"),
                    })
                    st.session_state.history = st.session_state.history[:20]

                except RuntimeError as e:
                    st.error(f"❌ API Error: {e}")
                    st.info("💡 Check your API key, quota, and internet connection.")
                    st.stop()
                except Exception as e:
                    st.error(f"❌ Unexpected error: {e}")
                    st.stop()

        # ── Display Summary ───────────────────────────────────────────────────
        if st.session_state.summary:
            st.divider()
            st.markdown('<div class="section-header">4. Summary</div>', unsafe_allow_html=True)

            # Search & highlight
            search_col, _ = st.columns([2, 3])
            with search_col:
                search_term = st.text_input("🔍 Search in summary", placeholder="Enter keyword…")

            display_text = st.session_state.summary
            if search_term:
                pattern = re.compile(re.escape(search_term), re.IGNORECASE)
                matches = len(pattern.findall(display_text))
                display_text_hl = pattern.sub(
                    lambda m: f'<span class="highlight">{m.group()}</span>',
                    display_text,
                )
                st.markdown(f'<span class="badge badge-blue">🔍 {matches} match(es) for "{search_term}"</span>', unsafe_allow_html=True)
                st.markdown(f'<div class="summary-box">{display_text_hl}</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="summary-box">{display_text}</div>', unsafe_allow_html=True)

            word_count = len(display_text.split())
            st.caption(f"📝 {word_count} words · {len(display_text)} characters · {st.session_state.summary_type}")

            st.divider()

            # ── Export ────────────────────────────────────────────────────────
            st.markdown('<div class="section-header">5. Export</div>', unsafe_allow_html=True)
            ec1, ec2 = st.columns([1, 2])
            with ec1:
                export_fmt = st.selectbox("Format", ["PDF", "DOCX", "PPTX", "TXT", "Markdown"])
            with ec2:
                export_title = st.text_input("Document Title", value=selected_name.replace(".pdf", ""))

            if st.button(f"⬇️ Download as {export_fmt}", use_container_width=True):
                try:
                    with st.spinner(f"Generating {export_fmt}…"):
                        file_bytes_out, filename, mime = export_summary(
                            st.session_state.summary, export_fmt, export_title
                        )
                    st.download_button(
                        label=f"📥 Click to download {filename}",
                        data=file_bytes_out,
                        file_name=filename,
                        mime=mime,
                        use_container_width=True,
                    )
                    st.success(f"✅ {export_fmt} ready for download!")
                except RuntimeError as e:
                    st.error(f"❌ Export failed: {e}")

            st.divider()

            # ── Video Generator ───────────────────────────────────────────────
            st.markdown('<div class="section-header">6. Video Generator (Optional)</div>', unsafe_allow_html=True)
            st.caption("Creates a slide-style educational video from your summary.")
            vc1, vc2 = st.columns(2)
            with vc1:
                secs_per_slide = st.slider("Seconds per slide", 3, 10, 5)
            with vc2:
                include_audio = st.checkbox("Include voice narration (gTTS)", value=False)

            if st.button("🎬 Generate Video", use_container_width=False):
                with st.spinner("🎬 Generating video — this may take 30–60 seconds…"):
                    try:
                        video_bytes = generate_video(
                            summary=st.session_state.summary,
                            title=export_title,
                            seconds_per_slide=secs_per_slide,
                            include_audio=include_audio,
                        )
                        if video_bytes:
                            st.download_button(
                                label="📥 Download Video (MP4)",
                                data=video_bytes,
                                file_name=f"{export_title.replace(' ', '_')}.mp4",
                                mime="video/mp4",
                                use_container_width=True,
                            )
                            st.success("✅ Video ready!")
                        else:
                            st.warning("⚠️ Video generation requires imageio and Pillow. Install with: pip install imageio[ffmpeg] Pillow")
                    except Exception as e:
                        st.error(f"❌ Video error: {e}")

    else:
        # Empty state
        st.markdown("""
        <div style="text-align:center;padding:60px 0;color:#64748b">
            <div style="font-size:3rem">📂</div>
            <div style="font-size:1.2rem;margin-top:12px;font-weight:600">Upload a PDF to get started</div>
            <div style="font-size:0.9rem;margin-top:6px">Supports text-based and scanned PDFs</div>
        </div>
        """, unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE: Prompt Library
# ═══════════════════════════════════════════════════════════════════════════════
elif page == "📚 Prompt Library":
    st.markdown("## 📚 Prompt Library")
    st.caption(f"Browse {sum(len(v) for v in PROMPT_LIBRARY.values())} curated prompts across {len(PROMPT_LIBRARY)} categories.")

    # Search prompts
    search = st.text_input("🔍 Search prompts", placeholder="e.g. exam, definition, timeline…")
    st.markdown("<br>", unsafe_allow_html=True)

    total_shown = 0
    for cat, prompts in PROMPT_LIBRARY.items():
        filtered = [p for p in prompts if not search or search.lower() in p.lower()]
        if not filtered:
            continue
        total_shown += len(filtered)

        category_colors = {
            "Exam Preparation": "badge-orange",
            "Assignment Help": "badge-blue",
            "Interview Prep": "badge-green",
            "Research": "badge-blue",
            "Notes Creation": "badge-orange",
            "Presentation Preparation": "badge-green",
            "Quick Revision": "badge-orange",
        }
        badge_cls = category_colors.get(cat, "badge-blue")

        with st.expander(f"{cat} ({len(filtered)})", expanded=search != ""):
            cols = st.columns(2)
            for i, prompt in enumerate(filtered):
                with cols[i % 2]:
                    st.markdown(f"""
                    <div style="background:#1e293b;border:1px solid #334155;border-radius:8px;
                                padding:10px 14px;margin-bottom:8px;font-size:0.86rem;color:#d1d5db;
                                cursor:pointer;line-height:1.4">
                        <span class="badge {badge_cls}">{cat}</span><br>
                        {prompt}
                    </div>
                    """, unsafe_allow_html=True)

    if search and total_shown == 0:
        st.info(f"No prompts found for '{search}'. Try a different keyword.")


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE: Dashboard
# ═══════════════════════════════════════════════════════════════════════════════
elif page == "📊 Dashboard":
    st.markdown("## 📊 Dashboard")
    st.caption("Statistics for your current session.")

    c1, c2, c3, c4 = st.columns(4)
    stats = [
        (st.session_state.total_pdfs, "PDFs Processed"),
        (st.session_state.total_pages, "Pages Extracted"),
        (f"{st.session_state.total_words:,}", "Words Processed"),
        (f"{st.session_state.processing_time:.1f}s", "Total Time"),
    ]
    for col, (val, label) in zip([c1, c2, c3, c4], stats):
        with col:
            st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{val}</div>
                <div class="stat-label">{label}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Summary type distribution
    if st.session_state.history:
        st.markdown("### 📈 Summary Type Distribution")
        from collections import Counter
        types = Counter(h["summary_type"] for h in st.session_state.history)
        total = sum(types.values())

        for stype, count in types.most_common():
            pct = int(count / total * 100)
            st.markdown(f"""
            <div style="margin-bottom:8px">
                <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                    <span style="font-size:0.88rem;color:#e2e8f0">{stype}</span>
                    <span style="font-size:0.88rem;color:#94a3b8">{count} ({pct}%)</span>
                </div>
                <div style="background:#1e293b;border-radius:4px;height:8px">
                    <div style="background:#1a56db;width:{pct}%;height:8px;border-radius:4px"></div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("### 📋 Recent Files")
        for h in st.session_state.history[:5]:
            st.markdown(f"""
            <div class="history-item">
                <strong>{h['filename']}</strong>
                <span class="badge badge-blue">{h['summary_type']}</span>
                <span class="badge badge-green">{h.get('language','English')}</span>
                <div class="ts">🕐 {h['ts']}</div>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.info("📭 No data yet. Generate summaries to populate the dashboard.")


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE: History
# ═══════════════════════════════════════════════════════════════════════════════
elif page == "📜 History":
    st.markdown("## 📜 Summary History")
    st.caption("Last 20 summaries from this session.")

    if not st.session_state.history:
        st.info("📭 No history yet. Generate summaries to see them here.")
    else:
        if st.button("🗑️ Clear History"):
            st.session_state.history = []
            st.rerun()

        for i, h in enumerate(st.session_state.history):
            with st.expander(f"📄 {h['filename']} — {h['summary_type']} ({h['ts']})"):
                st.markdown(f"""
                <div style="margin-bottom:8px">
                    <span class="badge badge-blue">{h['summary_type']}</span>
                    <span class="badge badge-green">{h.get('language','English')}</span>
                    <span style="color:#64748b;font-size:0.8rem;margin-left:8px">🕐 {h['ts']}</span>
                </div>
                """, unsafe_allow_html=True)
                st.markdown(f'<div class="summary-box">{h["summary"][:2000]}{"…" if len(h["summary"])>2000 else ""}</div>', unsafe_allow_html=True)

                # Re-export from history
                hc1, hc2 = st.columns([1, 3])
                with hc1:
                    hist_fmt = st.selectbox("Format", ["PDF", "DOCX", "PPTX", "TXT", "Markdown"],
                                             key=f"hist_fmt_{i}")
                if st.button(f"⬇️ Download", key=f"hist_dl_{i}"):
                    try:
                        fb, fn, mime = export_summary(h["summary"], hist_fmt, h["filename"].replace(".pdf",""))
                        st.download_button(f"📥 {fn}", data=fb, file_name=fn, mime=mime,
                                           key=f"hist_dl_btn_{i}")
                    except RuntimeError as e:
                        st.error(f"Export failed: {e}")
