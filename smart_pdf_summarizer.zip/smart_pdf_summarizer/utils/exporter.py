"""
Exporter Utility
Converts summary text to PDF, DOCX, PPTX, TXT, and Markdown.
"""

import io
import re
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

TIMESTAMP = lambda: datetime.now().strftime("%Y-%m-%d %H:%M")


# ─── TXT ─────────────────────────────────────────────────────────────────────

def export_txt(summary: str, title: str = "Summary") -> bytes:
    header = f"{title}\nGenerated: {TIMESTAMP()}\n{'='*60}\n\n"
    return (header + summary).encode("utf-8")


# ─── Markdown ─────────────────────────────────────────────────────────────────

def export_markdown(summary: str, title: str = "Summary") -> bytes:
    content = f"# {title}\n\n> Generated: {TIMESTAMP()}\n\n---\n\n{summary}\n"
    return content.encode("utf-8")


# ─── DOCX ────────────────────────────────────────────────────────────────────

def export_docx(summary: str, title: str = "Summary") -> bytes:
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        doc = Document()

        # Title
        heading = doc.add_heading(title, level=0)
        heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in heading.runs:
            run.font.color.rgb = RGBColor(0x1A, 0x56, 0xDB)

        # Metadata
        meta = doc.add_paragraph(f"Generated: {TIMESTAMP()}")
        meta.runs[0].font.size = Pt(9)
        meta.runs[0].font.color.rgb = RGBColor(0x6B, 0x72, 0x80)
        doc.add_paragraph()

        # Content: detect bullets and bold
        for line in summary.split("\n"):
            line = line.rstrip()
            if not line:
                doc.add_paragraph()
                continue
            if line.startswith("# "):
                doc.add_heading(line[2:], level=1)
            elif line.startswith("## "):
                doc.add_heading(line[3:], level=2)
            elif line.startswith("### "):
                doc.add_heading(line[4:], level=3)
            elif line.startswith(("- ", "• ", "* ")):
                p = doc.add_paragraph(style="List Bullet")
                _add_formatted_run(p, line[2:])
            elif re.match(r"^\d+\.", line):
                p = doc.add_paragraph(style="List Number")
                _add_formatted_run(p, re.sub(r"^\d+\.\s*", "", line))
            else:
                p = doc.add_paragraph()
                _add_formatted_run(p, line)

        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()
    except ImportError:
        raise RuntimeError("python-docx not installed. Run: pip install python-docx")
    except Exception as e:
        logger.error(f"DOCX export failed: {e}")
        raise RuntimeError(f"DOCX export failed: {e}")


def _add_formatted_run(paragraph, text: str):
    """Render **bold** and *italic* markdown in a paragraph."""
    import re
    from docx.shared import Pt
    parts = re.split(r"(\*\*.*?\*\*|\*.*?\*)", text)
    for part in parts:
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        elif part.startswith("*") and part.endswith("*"):
            run = paragraph.add_run(part[1:-1])
            run.italic = True
        else:
            paragraph.add_run(part)


# ─── PDF ──────────────────────────────────────────────────────────────────────

def export_pdf(summary: str, title: str = "Summary") -> bytes:
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                        HRFlowable)
        from reportlab.lib.enums import TA_CENTER, TA_LEFT

        buf = io.BytesIO()
        doc = SimpleDocTemplate(
            buf, pagesize=A4,
            leftMargin=2.5*cm, rightMargin=2.5*cm,
            topMargin=2.5*cm, bottomMargin=2.5*cm,
        )
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "CustomTitle", parent=styles["Title"],
            fontSize=20, textColor=colors.HexColor("#1A56DB"),
            spaceAfter=6, alignment=TA_CENTER,
        )
        meta_style = ParagraphStyle(
            "Meta", parent=styles["Normal"],
            fontSize=8, textColor=colors.grey, alignment=TA_CENTER, spaceAfter=12,
        )
        heading1 = ParagraphStyle(
            "H1", parent=styles["Heading1"],
            fontSize=14, textColor=colors.HexColor("#1A56DB"), spaceAfter=6,
        )
        body_style = ParagraphStyle(
            "Body", parent=styles["Normal"],
            fontSize=11, leading=16, spaceAfter=8,
        )
        bullet_style = ParagraphStyle(
            "Bullet", parent=styles["Normal"],
            fontSize=11, leading=16, leftIndent=20, spaceAfter=4,
            bulletIndent=10,
        )

        story = []
        story.append(Paragraph(title, title_style))
        story.append(Paragraph(f"Generated: {TIMESTAMP()}", meta_style))
        story.append(HRFlowable(width="100%", thickness=1,
                                 color=colors.HexColor("#E5E7EB")))
        story.append(Spacer(1, 0.3*cm))

        for line in summary.split("\n"):
            line = line.strip()
            if not line:
                story.append(Spacer(1, 0.2*cm))
            elif line.startswith("# "):
                story.append(Paragraph(line[2:], heading1))
            elif line.startswith("## "):
                story.append(Paragraph(line[3:], styles["Heading2"]))
            elif line.startswith(("- ", "• ", "* ")):
                story.append(Paragraph(f"• {_md_to_rl(line[2:])}", bullet_style))
            else:
                story.append(Paragraph(_md_to_rl(line), body_style))

        doc.build(story)
        return buf.getvalue()
    except ImportError:
        raise RuntimeError("reportlab not installed. Run: pip install reportlab")
    except Exception as e:
        logger.error(f"PDF export failed: {e}")
        raise RuntimeError(f"PDF export failed: {e}")


def _md_to_rl(text: str) -> str:
    """Convert **bold** and *italic* to ReportLab XML tags."""
    text = re.sub(r"\*\*(.*?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"\*(.*?)\*", r"<i>\1</i>", text)
    return text


# ─── PPTX ────────────────────────────────────────────────────────────────────

def export_pptx(summary: str, title: str = "Summary") -> bytes:
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt, Emu
        from pptx.dml.color import RGBColor
        from pptx.enum.text import PP_ALIGN

        prs = Presentation()
        prs.slide_width = Inches(13.33)
        prs.slide_height = Inches(7.5)

        blank_layout = prs.slide_layouts[6]  # blank

        # Color palette
        BG_COLOR = RGBColor(0x0F, 0x17, 0x2A)
        ACCENT = RGBColor(0x1A, 0x56, 0xDB)
        TEXT_WHITE = RGBColor(0xFF, 0xFF, 0xFF)
        TEXT_LIGHT = RGBColor(0xD1, 0xD5, 0xDB)

        def set_bg(slide, color: RGBColor):
            from pptx.util import Inches
            bg = slide.background
            fill = bg.fill
            fill.solid()
            fill.fore_color.rgb = color

        def add_text_box(slide, text, left, top, width, height,
                         font_size=18, bold=False, color=TEXT_WHITE,
                         alignment=PP_ALIGN.LEFT, word_wrap=True):
            txBox = slide.shapes.add_textbox(left, top, width, height)
            tf = txBox.text_frame
            tf.word_wrap = word_wrap
            p = tf.paragraphs[0]
            p.alignment = alignment
            run = p.add_run()
            run.text = text
            run.font.size = Pt(font_size)
            run.font.bold = bold
            run.font.color.rgb = color
            return txBox

        # ── Slide 1: Title ──────────────────────────────────────────────────
        slide = prs.slides.add_slide(blank_layout)
        set_bg(slide, BG_COLOR)
        # Accent bar
        shape = slide.shapes.add_shape(
            1, Inches(0), Inches(0), Inches(13.33), Inches(0.08)
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = ACCENT
        shape.line.fill.background()

        add_text_box(slide, title,
                     Inches(1), Inches(2.5), Inches(11.33), Inches(1.5),
                     font_size=36, bold=True, color=TEXT_WHITE,
                     alignment=PP_ALIGN.CENTER)
        add_text_box(slide, f"AI-Generated Summary  •  {TIMESTAMP()}",
                     Inches(1), Inches(4.2), Inches(11.33), Inches(0.5),
                     font_size=14, color=TEXT_LIGHT, alignment=PP_ALIGN.CENTER)

        # ── Parse summary into slides ────────────────────────────────────────
        sections = _parse_sections(summary)
        if not sections:
            sections = [("Key Points", summary[:2000])]

        for sec_title, sec_body in sections[:10]:  # max 10 content slides
            slide = prs.slides.add_slide(blank_layout)
            set_bg(slide, BG_COLOR)

            # Accent bar
            shape = slide.shapes.add_shape(
                1, Inches(0), Inches(0), Inches(13.33), Inches(0.06)
            )
            shape.fill.solid()
            shape.fill.fore_color.rgb = ACCENT
            shape.line.fill.background()

            # Section title
            add_text_box(slide, sec_title,
                         Inches(0.7), Inches(0.3), Inches(11.93), Inches(0.8),
                         font_size=24, bold=True, color=TEXT_WHITE)

            # Divider
            div = slide.shapes.add_shape(
                1, Inches(0.7), Inches(1.15), Inches(3), Inches(0.04)
            )
            div.fill.solid()
            div.fill.fore_color.rgb = ACCENT
            div.line.fill.background()

            # Body
            lines = [l for l in sec_body.strip().split("\n") if l.strip()]
            body_text = "\n".join(
                f"• {l.lstrip('- •*').strip()}" if l.startswith(("- ", "• ", "* ")) else l
                for l in lines[:12]
            )
            add_text_box(slide, body_text,
                         Inches(0.7), Inches(1.4), Inches(11.93), Inches(5.5),
                         font_size=16, color=TEXT_LIGHT)

        # ── Thank you slide ──────────────────────────────────────────────────
        slide = prs.slides.add_slide(blank_layout)
        set_bg(slide, BG_COLOR)
        shape = slide.shapes.add_shape(
            1, Inches(0), Inches(0), Inches(13.33), Inches(0.08)
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = ACCENT
        shape.line.fill.background()
        add_text_box(slide, "Thank You", Inches(1), Inches(3), Inches(11.33), Inches(1),
                     font_size=40, bold=True, color=TEXT_WHITE, alignment=PP_ALIGN.CENTER)
        add_text_box(slide, "Generated by Smart PDF Summarizer",
                     Inches(1), Inches(4.2), Inches(11.33), Inches(0.5),
                     font_size=14, color=TEXT_LIGHT, alignment=PP_ALIGN.CENTER)

        buf = io.BytesIO()
        prs.save(buf)
        return buf.getvalue()
    except ImportError:
        raise RuntimeError("python-pptx not installed. Run: pip install python-pptx")
    except Exception as e:
        logger.error(f"PPTX export failed: {e}")
        raise RuntimeError(f"PPTX export failed: {e}")


def _parse_sections(text: str) -> list[tuple[str, str]]:
    """Parse markdown headers into (title, body) tuples."""
    sections = []
    current_title = "Summary"
    current_body = []
    for line in text.split("\n"):
        if line.startswith("# "):
            if current_body:
                sections.append((current_title, "\n".join(current_body)))
                current_body = []
            current_title = line[2:].strip()
        elif line.startswith("## "):
            if current_body:
                sections.append((current_title, "\n".join(current_body)))
                current_body = []
            current_title = line[3:].strip()
        else:
            current_body.append(line)
    if current_body:
        sections.append((current_title, "\n".join(current_body)))
    return sections if sections else [("Summary", text)]


# ─── Public dispatch ──────────────────────────────────────────────────────────

def export_summary(summary: str, fmt: str, title: str = "Summary") -> tuple[bytes, str, str]:
    """
    Returns (file_bytes, filename, mime_type).
    fmt: one of 'PDF', 'DOCX', 'PPTX', 'TXT', 'Markdown'
    """
    safe_title = re.sub(r"[^\w\s-]", "", title).strip().replace(" ", "_")[:40]
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    if fmt == "PDF":
        return export_pdf(summary, title), f"{safe_title}_{ts}.pdf", "application/pdf"
    elif fmt == "DOCX":
        return export_docx(summary, title), f"{safe_title}_{ts}.docx", \
               "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    elif fmt == "PPTX":
        return export_pptx(summary, title), f"{safe_title}_{ts}.pptx", \
               "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    elif fmt == "TXT":
        return export_txt(summary, title), f"{safe_title}_{ts}.txt", "text/plain"
    elif fmt == "Markdown":
        return export_markdown(summary, title), f"{safe_title}_{ts}.md", "text/markdown"
    else:
        raise ValueError(f"Unknown export format: {fmt}")
