"""
Video Generator Utility
Creates a slide-style educational video from summary text.
Uses Pillow for frames, imageio for video assembly.
Optional TTS via gTTS for narration.
"""

import io
import os
import logging
import textwrap
import tempfile
from typing import Optional

logger = logging.getLogger(__name__)


def _parse_slides(summary: str, max_slides: int = 8) -> list[dict]:
    """Convert summary text into slide data [{title, points}]."""
    slides = []
    current_title = "Summary"
    current_points = []

    for line in summary.split("\n"):
        line = line.strip()
        if not line:
            continue
        if line.startswith("# "):
            if current_points:
                slides.append({"title": current_title, "points": current_points[:6]})
                current_points = []
            current_title = line[2:].strip()
        elif line.startswith("## "):
            if current_points:
                slides.append({"title": current_title, "points": current_points[:6]})
                current_points = []
            current_title = line[3:].strip()
        elif line.startswith(("- ", "• ", "* ")):
            current_points.append(line[2:].strip())
        elif len(line) > 10:
            current_points.append(line[:120])

    if current_points:
        slides.append({"title": current_title, "points": current_points[:6]})

    if not slides:
        # No headers found, split into equal chunks
        lines = [l.strip() for l in summary.split("\n") if l.strip()]
        chunk_size = max(1, len(lines) // max_slides)
        for i in range(0, min(len(lines), max_slides * chunk_size), chunk_size):
            slides.append({
                "title": f"Section {i // chunk_size + 1}",
                "points": lines[i:i + chunk_size][:6],
            })

    return slides[:max_slides]


def _draw_slide(title: str, points: list[str], slide_num: int,
                total: int, width: int = 1280, height: int = 720):
    """Render a single slide as a PIL Image."""
    try:
        from PIL import Image, ImageDraw, ImageFont
        import numpy as np

        img = Image.new("RGB", (width, height), color=(15, 23, 42))  # dark navy
        draw = ImageDraw.Draw(img)

        # Gradient header bar
        for y in range(80):
            r = int(26 + (y / 80) * 10)
            g = int(86 + (y / 80) * 10)
            b = int(219 - (y / 80) * 30)
            draw.line([(0, y), (width, y)], fill=(r, g, b))

        # Accent bottom bar
        draw.rectangle([(0, height - 6), (width, height)], fill=(26, 86, 219))

        # Slide counter
        draw.text((width - 100, 28), f"{slide_num}/{total}",
                  fill=(255, 255, 255), anchor="rm")

        # Title
        try:
            font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 42)
            font_body = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 26)
            font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
        except Exception:
            font_title = ImageFont.load_default()
            font_body = font_title
            font_small = font_title

        # Wrap title
        title_wrapped = textwrap.fill(title, width=50)
        draw.text((60, 20), title_wrapped, font=font_title, fill=(255, 255, 255))

        # Divider
        draw.line([(60, 90), (width - 60, 90)], fill=(30, 100, 230), width=2)

        # Bullet points
        y_pos = 120
        for i, point in enumerate(points):
            if y_pos > height - 80:
                break
            # Bullet dot
            draw.ellipse([(60, y_pos + 8), (74, y_pos + 22)], fill=(26, 86, 219))
            # Wrap text
            wrapped = textwrap.fill(point, width=70)
            draw.text((90, y_pos), wrapped, font=font_body, fill=(209, 213, 219))
            lines_count = wrapped.count("\n") + 1
            y_pos += lines_count * 36 + 10

        # Footer
        draw.text((60, height - 40), "Smart PDF Summarizer",
                  font=font_small, fill=(75, 85, 99))

        return img
    except ImportError:
        raise RuntimeError("Pillow not installed. Run: pip install Pillow")


def generate_tts_audio(text: str, lang: str = "en") -> Optional[str]:
    """Generate TTS audio using gTTS. Returns path to MP3 file or None."""
    try:
        from gtts import gTTS
        tts = gTTS(text=text[:3000], lang=lang, slow=False)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
            tts.save(f.name)
            return f.name
    except ImportError:
        logger.warning("gTTS not installed — skipping audio narration.")
        return None
    except Exception as e:
        logger.warning(f"TTS generation failed: {e}")
        return None


def generate_video(
    summary: str,
    title: str = "Summary",
    fps: int = 1,
    seconds_per_slide: int = 5,
    include_audio: bool = False,
    language: str = "en",
) -> Optional[bytes]:
    """
    Generate an educational slide video from a summary.
    Returns MP4 bytes or None if generation fails.
    """
    try:
        import imageio.v3 as iio
        import numpy as np

        slides = _parse_slides(summary)
        if not slides:
            raise ValueError("No slides could be generated from the summary.")

        total = len(slides)
        frames = []

        for i, slide in enumerate(slides):
            img = _draw_slide(
                title=slide["title"],
                points=slide["points"],
                slide_num=i + 1,
                total=total,
            )
            frame = np.array(img)
            # Repeat frame for duration
            for _ in range(fps * seconds_per_slide):
                frames.append(frame)

        if not frames:
            raise ValueError("No frames generated.")

        buf = io.BytesIO()
        iio.imwrite(buf, frames, extension=".mp4", fps=fps, codec="libx264",
                    pixelformat="yuv420p", output_params=["-preset", "ultrafast"])
        return buf.getvalue()

    except ImportError as e:
        logger.warning(f"Video generation dependency missing: {e}")
        return None
    except Exception as e:
        logger.error(f"Video generation failed: {e}")
        return None
