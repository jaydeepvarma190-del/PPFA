"""
PDF Reader Utility
Handles PDF extraction using multiple libraries with fallback support.
Supports scanned PDFs via OCR.
"""

import io
import time
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def extract_text_pypdf2(file_bytes: bytes) -> tuple[str, int]:
    """Extract text using PyPDF2."""
    try:
        import PyPDF2
        reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
        text = ""
        num_pages = len(reader.pages)
        for page in reader.pages:
            extracted = page.extract_text()
            if extracted:
                text += extracted + "\n\n"
        return text.strip(), num_pages
    except Exception as e:
        logger.warning(f"PyPDF2 extraction failed: {e}")
        return "", 0


def extract_text_pdfplumber(file_bytes: bytes) -> tuple[str, int]:
    """Extract text using pdfplumber (better for tables and formatting)."""
    try:
        import pdfplumber
        text = ""
        num_pages = 0
        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            num_pages = len(pdf.pages)
            for page in pdf.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n\n"
        return text.strip(), num_pages
    except Exception as e:
        logger.warning(f"pdfplumber extraction failed: {e}")
        return "", 0


def extract_text_pymupdf(file_bytes: bytes) -> tuple[str, int]:
    """Extract text using PyMuPDF (fitz) – fastest and most reliable."""
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        text = ""
        num_pages = len(doc)
        for page in doc:
            text += page.get_text() + "\n\n"
        doc.close()
        return text.strip(), num_pages
    except Exception as e:
        logger.warning(f"PyMuPDF extraction failed: {e}")
        return "", 0


def is_scanned_pdf(text: str, num_pages: int) -> bool:
    """Heuristic: if very little text extracted relative to pages, likely scanned."""
    if num_pages == 0:
        return False
    avg_chars = len(text) / max(num_pages, 1)
    return avg_chars < 100


def ocr_pdf(file_bytes: bytes) -> str:
    """Attempt OCR on scanned PDF using pytesseract + pdf2image."""
    try:
        import pytesseract
        from pdf2image import convert_from_bytes
        from PIL import Image

        images = convert_from_bytes(file_bytes, dpi=200)
        text = ""
        for img in images:
            text += pytesseract.image_to_string(img) + "\n\n"
        return text.strip()
    except ImportError:
        return "[OCR not available — install pytesseract and pdf2image for scanned PDF support]"
    except Exception as e:
        logger.error(f"OCR failed: {e}")
        return f"[OCR failed: {e}]"


def extract_pdf_metadata(file_bytes: bytes) -> dict:
    """Extract PDF metadata (title, author, creation date)."""
    meta = {}
    try:
        import fitz
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        raw_meta = doc.metadata
        meta = {
            "title": raw_meta.get("title", "Unknown"),
            "author": raw_meta.get("author", "Unknown"),
            "subject": raw_meta.get("subject", ""),
            "creator": raw_meta.get("creator", ""),
            "pages": len(doc),
        }
        doc.close()
    except Exception as e:
        logger.warning(f"Metadata extraction failed: {e}")
    return meta


def read_pdf(file_bytes: bytes) -> dict:
    """
    Main entry: try multiple extractors, fall back to OCR if needed.
    Returns a dict with text, num_pages, word_count, is_scanned, metadata, processing_time.
    """
    start = time.time()

    # Validate file
    if len(file_bytes) == 0:
        raise ValueError("Uploaded file is empty.")
    if len(file_bytes) > 50 * 1024 * 1024:  # 50 MB limit
        raise ValueError("File exceeds 50 MB limit.")
    if not file_bytes[:4] == b'%PDF':
        raise ValueError("File does not appear to be a valid PDF.")

    text = ""
    num_pages = 0

    # Try PyMuPDF first (fastest)
    text, num_pages = extract_text_pymupdf(file_bytes)

    # Fallback to pdfplumber
    if not text:
        text, num_pages = extract_text_pdfplumber(file_bytes)

    # Fallback to PyPDF2
    if not text:
        text, num_pages = extract_text_pypdf2(file_bytes)

    scanned = is_scanned_pdf(text, num_pages)

    if scanned or not text:
        ocr_text = ocr_pdf(file_bytes)
        if ocr_text and not ocr_text.startswith("[OCR"):
            text = ocr_text
            scanned = True

    if not text:
        raise ValueError("Could not extract any text from this PDF. It may be corrupted or image-only without OCR support.")

    word_count = len(text.split())
    processing_time = round(time.time() - start, 2)
    metadata = extract_pdf_metadata(file_bytes)
    if num_pages == 0:
        num_pages = metadata.get("pages", 0)

    return {
        "text": text,
        "num_pages": num_pages,
        "word_count": word_count,
        "char_count": len(text),
        "is_scanned": scanned,
        "metadata": metadata,
        "processing_time": processing_time,
    }
