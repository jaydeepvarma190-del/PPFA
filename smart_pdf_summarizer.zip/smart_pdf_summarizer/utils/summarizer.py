"""
AI Summarizer Utility
Supports Google Gemini API and OpenAI API.
Handles chunking for large documents.
"""

import os
import time
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# ─── Chunking ────────────────────────────────────────────────────────────────

MAX_CHUNK_CHARS = 12000  # safe for Gemini / GPT-4o


def chunk_text(text: str, max_chars: int = MAX_CHUNK_CHARS) -> list[str]:
    """Split text into overlapping chunks."""
    if len(text) <= max_chars:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = start + max_chars
        if end < len(text):
            # Break at paragraph boundary
            boundary = text.rfind("\n\n", start, end)
            if boundary > start:
                end = boundary
        chunks.append(text[start:end].strip())
        start = end
    return chunks


# ─── Prompt templates ────────────────────────────────────────────────────────

SUMMARY_PROMPTS = {
    "Short Summary": (
        "Provide a concise summary of the following document in 150–200 words. "
        "Capture the core message clearly.\n\nDocument:\n{text}"
    ),
    "Detailed Summary": (
        "Write a comprehensive, detailed summary of the following document. "
        "Cover all major sections, arguments, evidence, and conclusions. "
        "Aim for 400–600 words.\n\nDocument:\n{text}"
    ),
    "Bullet Summary": (
        "Extract the key points from the following document as a clean, "
        "structured bullet-point list grouped under relevant headings. "
        "Each bullet should be a complete, informative statement.\n\nDocument:\n{text}"
    ),
    "Chapter-wise Summary": (
        "Identify the chapters or major sections of the following document and "
        "write a 3–5 sentence summary for each section. Label each section clearly.\n\nDocument:\n{text}"
    ),
    "Exam Revision Notes": (
        "Generate exam-ready revision notes from the following document. "
        "Include: key definitions, important facts, formulas or rules, must-know concepts, "
        "and possible exam questions with brief answers.\n\nDocument:\n{text}"
    ),
    "Key Concepts": (
        "List and explain the 10 most important concepts from the following document. "
        "For each concept: (1) name it, (2) define it, (3) explain its significance.\n\nDocument:\n{text}"
    ),
    "Important Definitions": (
        "Extract all important terms and their definitions from the following document. "
        "Format as: **Term**: Definition. Group by topic if possible.\n\nDocument:\n{text}"
    ),
    "Custom Prompt": "{custom_prompt}\n\nDocument:\n{text}",
}


# ─── Gemini ───────────────────────────────────────────────────────────────────

def summarize_with_gemini(text: str, summary_type: str, api_key: str,
                          custom_prompt: Optional[str] = None,
                          language: str = "English") -> str:
    """Call Google Gemini API (gemini-1.5-flash)."""
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-1.5-flash")

        prompt_template = SUMMARY_PROMPTS.get(summary_type, SUMMARY_PROMPTS["Short Summary"])
        prompt = prompt_template.format(text=text[:MAX_CHUNK_CHARS],
                                        custom_prompt=custom_prompt or "")
        if language != "English":
            prompt += f"\n\nRespond in {language}."

        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        logger.error(f"Gemini API error: {e}")
        raise RuntimeError(f"Gemini API error: {e}")


def summarize_large_with_gemini(text: str, summary_type: str, api_key: str,
                                 custom_prompt: Optional[str] = None,
                                 language: str = "English",
                                 progress_callback=None) -> str:
    """Chunk-based summarization for large documents using Gemini."""
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-1.5-flash")

        chunks = chunk_text(text)
        if len(chunks) == 1:
            return summarize_with_gemini(text, summary_type, api_key, custom_prompt, language)

        # Summarize each chunk
        partial_summaries = []
        for i, chunk in enumerate(chunks):
            if progress_callback:
                progress_callback(i / len(chunks), f"Processing chunk {i+1}/{len(chunks)}…")
            prompt = (
                f"Summarize this section of a larger document clearly and concisely "
                f"(section {i+1} of {len(chunks)}):\n\n{chunk}"
            )
            if language != "English":
                prompt += f"\n\nRespond in {language}."
            resp = model.generate_content(prompt)
            partial_summaries.append(resp.text.strip())
            time.sleep(0.5)  # Rate limiting

        # Final synthesis
        if progress_callback:
            progress_callback(0.9, "Synthesizing final summary…")
        combined = "\n\n---\n\n".join(partial_summaries)
        prompt_template = SUMMARY_PROMPTS.get(summary_type, SUMMARY_PROMPTS["Detailed Summary"])
        final_prompt = (
            f"The following are summaries of different sections of a document. "
            f"Synthesize them into a single coherent {summary_type}:\n\n{combined}"
        )
        if language != "English":
            final_prompt += f"\n\nRespond in {language}."
        final = model.generate_content(final_prompt)
        return final.text.strip()
    except Exception as e:
        logger.error(f"Gemini chunked error: {e}")
        raise RuntimeError(f"Gemini API error: {e}")


# ─── OpenAI ───────────────────────────────────────────────────────────────────

def summarize_with_openai(text: str, summary_type: str, api_key: str,
                          custom_prompt: Optional[str] = None,
                          language: str = "English") -> str:
    """Call OpenAI API (gpt-4o-mini)."""
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)

        prompt_template = SUMMARY_PROMPTS.get(summary_type, SUMMARY_PROMPTS["Short Summary"])
        user_content = prompt_template.format(text=text[:MAX_CHUNK_CHARS],
                                              custom_prompt=custom_prompt or "")
        system = "You are an expert academic summarizer helping students learn effectively."
        if language != "English":
            system += f" Always respond in {language}."

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user_content},
            ],
            max_tokens=2000,
            temperature=0.5,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        logger.error(f"OpenAI API error: {e}")
        raise RuntimeError(f"OpenAI API error: {e}")


# ─── Public interface ─────────────────────────────────────────────────────────

def generate_summary(
    text: str,
    summary_type: str,
    api_provider: str,
    api_key: str,
    custom_prompt: Optional[str] = None,
    language: str = "English",
    progress_callback=None,
) -> str:
    """
    Main summarization entry point.
    Automatically handles large texts via chunking.
    """
    if not text or not text.strip():
        raise ValueError("No text provided for summarization.")
    if not api_key or not api_key.strip():
        raise ValueError("API key is required.")

    start = time.time()
    is_large = len(text) > MAX_CHUNK_CHARS

    if api_provider == "Google Gemini":
        if is_large:
            result = summarize_large_with_gemini(text, summary_type, api_key,
                                                  custom_prompt, language, progress_callback)
        else:
            result = summarize_with_gemini(text, summary_type, api_key, custom_prompt, language)
    elif api_provider == "OpenAI":
        result = summarize_with_openai(text, summary_type, api_key, custom_prompt, language)
    else:
        raise ValueError(f"Unknown API provider: {api_provider}")

    elapsed = round(time.time() - start, 2)
    logger.info(f"Summary generated in {elapsed}s using {api_provider}")
    return result
